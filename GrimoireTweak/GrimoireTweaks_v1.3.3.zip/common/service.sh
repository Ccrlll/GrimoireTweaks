#!/system/bin/sh
MODDIR=${0%/*}

nohup sh $MODDIR/GrimoireTweaks/on_system > /dev/null & 2>&1